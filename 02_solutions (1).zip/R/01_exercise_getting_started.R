# Solve these exercises by filling in the function bodies, and try to read up on
# things that you didn't know or surprise you.

# write a function that multiplies x by y
# x and y are both single numbers.
ex01Multiply <- function(x, y) {
  # your code
  x * y
}

# write a function that multiplies x by y
# x and y are numeric vectors. Does this function need to
# differ from the one above?
ex02MultiplyVectors <- function(x, y) {
  # your code
  x * y
}

# write a function that checks if a "logical", a "numeric", or a "character" vector or something else.
# the function should return "lg" if the input is logical, "nm" if it is numeric, "ch" for characters,
# and otherwise "x".
ex03VectorType <- function(x) {
  # your code
  if (is.logical(x)) {
    "lg"
  } else if (is.numeric(x)) {
    "nm"
  } else if (is.character(x)) {
    "ch"
  } else {
    "x"
  }
  # alternatively
  switch(mode(x),
    logical = "lg",
    numeric = "nm",
    character = "ch",
    "x"
  )
}

# write a function that takes a vector of integers and returns all numbers that are odd.
# an empty vector should be returned when no odd numbers are found.
ex04Odd <- function(x) {
  # your code
  x[x %% 2 == 1]
}
